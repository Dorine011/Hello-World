import ecommerce.Shopping.sales as sales
import sys

print(sys.path)